import { router, useForm } from '@inertiajs/react';
import { Package } from 'lucide-react';
import * as React from 'react';

import { FormPageShell } from '@/components/shared/form-page-shell';
import { ProductForm } from '@/features/products/components/product-form';
import type { ProductFormValues } from '@/features/products/schemas/product.schema';
import { objectToFormData } from '@/lib/object-to-form-data';
import { showMutationSuccess } from '@/lib/mutation-toast';
import { toast } from 'sonner';

export function ProductCreatePage() {
  const [processing, setProcessing] = React.useState(false);
  useForm({});

  return (
    <FormPageShell
      backTo="/admin/products"
      backLabel="Back to Products"
      title="Create Product"
      description="Add a new NFC card product to your catalog"
      icon={Package}
    >
      <ProductForm
        mode="create"
        variant="page"
        isSubmitting={processing}
        onCancel={() => router.visit('/admin/products')}
        onSubmit={async (values: ProductFormValues, image?: File | null, galleryImages?: File[]) => {
          setProcessing(true);
          router.post(
            '/admin/products',
            objectToFormData(values as Record<string, unknown>, {
              image,
              gallery_images: galleryImages ?? [],
            }),
            {
              forceFormData: true,
              onSuccess: () => showMutationSuccess('Product created'),
              onError: (errors) => {
                const message = Object.values(errors).flat().join(' ');
                toast.error(message || 'Failed to create product');
              },
              onFinish: () => setProcessing(false),
            },
          );
        }}
      />
    </FormPageShell>
  );
}
